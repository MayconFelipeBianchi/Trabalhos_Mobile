package com.example.trabalho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalho.Controlers.ControlerClientes;
import com.example.trabalho.classes.Clientes;

public class CadastrarClientes extends AppCompatActivity {

    private EditText edNome;
    private EditText edCPF;
    private TextView tvLista;
    private Button btCadastrarCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_clientes);
        edNome = findViewById(R.id.edNome);
        edCPF = findViewById(R.id.edCPF);
        tvLista = findViewById(R.id.tvLista);
        btCadastrarCliente = findViewById(R.id.btCadastrarCliente);

        atualizarListaClientes();

        btCadastrarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarClientes();
            }
        });
    }

    private void salvarClientes() {
        int cpf;
        if (edCPF.getText().toString().isEmpty()) {
            edCPF.setError("Um Cpf deve ser informado!");
            return;
        } else {
            try {
                cpf = Integer.parseInt(edCPF.getText().toString());
            } catch (Exception ex) {
                edCPF.setError("Informe somente números!");
                return;
            }
        }
        if (edNome.getText().toString().isEmpty()) {
            edNome.setError("O nome do Cliente deve ser informado!");
            return;
        }

        Clientes clientes = new Clientes();
        clientes.setNome(edNome.getText().toString());
        clientes.setCpf(edCPF.getText().toString());

        ControlerClientes.getInstanciaCliente().salvarClientes(clientes);

        Toast.makeText(CadastrarClientes.this, "Cliente" + " cadastrado com sucesso!", Toast.LENGTH_LONG).show();

        finish();
    }

    private void atualizarListaClientes() {
        String texto = "";
        for (Clientes clientes : ControlerClientes.getInstanciaCliente().retornarClientes()) {
            texto += "Nome: " + clientes.getNome() + "\n" + "CPF: " + clientes.getCpf() + "\n" + "-----------------------------------------\n";
        }
        tvLista.setText(texto);

    }
}