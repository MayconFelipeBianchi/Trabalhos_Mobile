package com.example.trabalho;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.trabalho.Controlers.ControlerItens;
import com.example.trabalho.classes.Itens;

public class ItensDeVenda extends AppCompatActivity {

    private EditText edItem;
    private EditText edDescricao;
    private EditText edValor;
    private Button btCadastrar;
    private EditText edNome;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itens_de_venda);

        edItem = findViewById(R.id.edItem);
        edDescricao = findViewById(R.id.edDescricao);
        edValor = findViewById(R.id.edValor);
        btCadastrar = findViewById(R.id.btCadastrar);
        edNome = findViewById(R.id.edNome);

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastroItem();
                onRestart();
            }
        });
    }

    private void cadastroItem() {
        if (edNome.getText().toString().isEmpty()) {
            edNome.setError("Informe o nome do item");
            return;
        }
        if (edItem.getText().toString().isEmpty()) {
            edItem.setError("Informe o código do item");
            return;
        }
        if (edDescricao.getText().toString().isEmpty()) {
            edDescricao.setError("Informe a descrição do item");
            return;
        }
        if (edValor.getText().toString().isEmpty()) {
            edValor.setError("Informe o valor do item");
            return;
        }

        Itens itens = new Itens();
        itens.setCodigo(Integer.parseInt(edItem.getText().toString()));
        itens.setValor(Double.parseDouble(edValor.getText().toString()));
        itens.setNome(edNome.getText().toString());
        itens.setDescricao(edDescricao.getText().toString());

        ControlerItens.getInstanciaItem().salvarItens(itens);
        finish();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(ItensDeVenda.this, "Item" +
                " cadastrado com sucesso", Toast.LENGTH_LONG).show();
    }
}